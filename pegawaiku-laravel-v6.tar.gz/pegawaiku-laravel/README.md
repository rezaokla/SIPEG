# Pegawaiku Laravel + MySQL

Konversi proyek Pegawaiku dari versi localStorage HTML menjadi struktur aplikasi Laravel + MySQL.

## Status saat ini
- Struktur Laravel-style sudah dibuat.
- Route login, dashboard, users, dan pegawai sudah disiapkan.
- CRUD nyata untuk modul **users** dan **pegawai** sudah diimplementasikan pada level controller + blade.
- Migration MySQL untuk tabel utama sudah tersedia.
- Modul users, pegawai, cuti, program, anggaran, prestasi, laporan, dan profil sudah memiliki implementasi dasar. Fase berikutnya berfokus pada penyempurnaan validasi, dashboard lanjutan, chart, export, dan hardening aplikasi.

## Stack
- Laravel
- MySQL
- Blade Views
- Middleware role sederhana

## Modul
- Login
- Dashboard
- Users ✅
- Pegawai ✅
- Cuti ✅
- Program ✅
- Anggaran ✅
- Prestasi ✅
- Laporan ✅
- Profil ✅

## Langkah integrasi ke project Laravel asli
1. Buat project Laravel baru.
2. Salin folder `app`, `resources`, `routes`, `public/css`, dan `database` dari scaffold ini.
3. Daftarkan `RoleMiddleware` di `app/Http/Kernel.php` sebagai alias `role`.
4. Sesuaikan `.env` untuk koneksi MySQL.
5. Jalankan `php artisan migrate`.
6. Lengkapi controller scaffold lain secara bertahap.


## Seeder akun awal
Jalankan `php artisan db:seed` untuk membuat akun awal berikut:
- admin@pegawaiku.local / password123
- pimpinan@pegawaiku.local / password123
- pegawai@pegawaiku.local / password123

## Rekomendasi tahap produksi
- Daftarkan middleware `role` di `app/Http/Kernel.php`.
- Tambahkan policy Laravel resmi di `AuthServiceProvider`.
- Gunakan seeder, bukan SQL manual, untuk password hash yang aman.
- Tambahkan package export Excel/PDF pada tahap berikutnya.


## Finalisasi tambahan
File tambahan yang sudah disiapkan:
- `app/Providers/AuthServiceProvider.php`
- `app/Policies/*.php`
- `PRODUCTION_CHECKLIST.md`

Policy ini adalah fondasi agar otorisasi bisa dipindahkan bertahap dari pengecekan manual di controller ke policy Laravel resmi.
