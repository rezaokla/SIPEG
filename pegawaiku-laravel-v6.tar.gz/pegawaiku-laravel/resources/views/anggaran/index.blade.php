@extends('layouts.app')

@section('content')
<div class="grid stats-grid">
    <div class="card"><div class="kpi">Rp {{ number_format($master->total ?? 0, 0, ',', '.') }}</div><div class="muted">Master Anggaran</div></div>
    <div class="card"><div class="kpi">Rp {{ number_format($totalProgram, 0, ',', '.') }}</div><div class="muted">Total Alokasi Program</div></div>
    <div class="card"><div class="kpi">Rp {{ number_format($totalRealisasi, 0, ',', '.') }}</div><div class="muted">Total Realisasi</div></div>
    <div class="card"><div class="kpi">Rp {{ number_format($master->sisa ?? 0, 0, ',', '.') }}</div><div class="muted">Sisa Master</div></div>
</div>

<div class="card form-card">
    <h3>Master Anggaran</h3>
    <form method="POST" action="{{ route('anggaran.master.update') }}">
        @csrf @method('PUT')
        <label>Total Master Anggaran</label>
        <input type="number" name="total" min="0" value="{{ old('total', $master->total ?? 0) }}" required>
        <label>Keterangan</label>
        <input type="text" name="keterangan" value="{{ old('keterangan', $master->keterangan ?? '') }}">
        <div class="form-actions">
            <button type="submit" class="btn">Simpan</button>
        </div>
    </form>
</div>

<div class="card">
    <h3>Rekap Anggaran Program</h3>
    <table class="table">
        <thead>
            <tr>
                <th>Program</th>
                <th>PJ</th>
                <th>Anggaran</th>
                <th>Realisasi</th>
                <th>Sisa</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            @forelse($program as $item)
            <tr>
                <td>{{ $item->nama }}</td>
                <td>{{ $item->penanggungJawab->nama ?? '-' }}</td>
                <td>Rp {{ number_format($item->anggaran, 0, ',', '.') }}</td>
                <td>Rp {{ number_format($item->realisasi, 0, ',', '.') }}</td>
                <td>Rp {{ number_format($item->sisa_anggaran, 0, ',', '.') }}</td>
                <td>{{ $item->status_approval }}</td>
            </tr>
            @empty
            <tr><td colspan="6">Belum ada data program.</td></tr>
            @endforelse
        </tbody>
    </table>
    <div class="pagination-wrap">{{ $program->links() }}</div>
</div>
@endsection
