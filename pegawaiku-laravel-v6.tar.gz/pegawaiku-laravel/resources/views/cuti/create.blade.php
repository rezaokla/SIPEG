@extends('layouts.app')

@section('content')
<div class="card form-card">
    <h3>Ajukan Cuti</h3>
    <form method="POST" action="{{ route('cuti.store') }}">
        @csrf
        @include('cuti.form')
        <div class="form-actions">
            <a href="{{ route('cuti.index') }}" class="btn secondary">Batal</a>
            <button type="submit" class="btn">Simpan</button>
        </div>
    </form>
</div>
@endsection
