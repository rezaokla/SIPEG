@extends('layouts.app')

@section('content')
<div class="card form-card">
    <h3>Edit Pengajuan Cuti</h3>
    <form method="POST" action="{{ route('cuti.update', $cuti) }}">
        @csrf @method('PUT')
        @include('cuti.form')
        <div class="form-actions">
            <a href="{{ route('cuti.index') }}" class="btn secondary">Batal</a>
            <button type="submit" class="btn">Update</button>
        </div>
    </form>
</div>
@endsection
