<label>Pegawai</label>
<select name="pegawai_id" required>
    @foreach($pegawaiList as $pegawai)
        <option value="{{ $pegawai->id }}" @selected(old('pegawai_id', $cuti->pegawai_id ?? '') == $pegawai->id)>{{ $pegawai->nama }}{{ $pegawai->nip ? ' - '.$pegawai->nip : '' }}</option>
    @endforeach
</select>
<label>Jenis Cuti</label>
<select name="jenis" required>
    @foreach(['Tahunan','Sakit','Melahirkan','Alasan Penting'] as $jenis)
        <option value="{{ $jenis }}" @selected(old('jenis', $cuti->jenis ?? '') === $jenis)>{{ $jenis }}</option>
    @endforeach
</select>
<div class="grid two-col">
    <div>
        <label>Tanggal Mulai</label>
        <input type="date" name="tanggal_mulai" value="{{ old('tanggal_mulai', $cuti->tanggal_mulai ?? '') }}" required>
    </div>
    <div>
        <label>Tanggal Selesai</label>
        <input type="date" name="tanggal_selesai" value="{{ old('tanggal_selesai', $cuti->tanggal_selesai ?? '') }}" required>
    </div>
</div>
<label>Alasan</label>
<textarea name="alasan" rows="4" required>{{ old('alasan', $cuti->alasan ?? '') }}</textarea>
