@extends('layouts.app')

@section('content')
<div class="card">
    <div class="toolbar">
        <form method="GET" class="filter-row multi">
            <input type="text" name="keyword" value="{{ request('keyword') }}" placeholder="Cari nama pegawai / NIP">
            <select name="jenis">
                <option value="">Semua Jenis</option>
                @foreach(['Tahunan','Sakit','Melahirkan','Alasan Penting'] as $jenis)
                    <option value="{{ $jenis }}" @selected(request('jenis')===$jenis)>{{ $jenis }}</option>
                @endforeach
            </select>
            <select name="status">
                <option value="">Semua Status</option>
                @foreach(['Diajukan','Disetujui','Ditolak'] as $status)
                    <option value="{{ $status }}" @selected(request('status')===$status)>{{ $status }}</option>
                @endforeach
            </select>
            <button type="submit" class="btn">Filter</button>
        </form>
        <a href="{{ route('cuti.create') }}" class="btn">+ Ajukan Cuti</a>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>Pegawai</th>
                <th>Jenis</th>
                <th>Periode</th>
                <th>Status</th>
                <th>Catatan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($cuti as $item)
            <tr>
                <td>{{ $item->pegawai->nama ?? '-' }}</td>
                <td>{{ $item->jenis }}</td>
                <td>{{ $item->tanggal_mulai }} s/d {{ $item->tanggal_selesai }}</td>
                <td><span class="badge">{{ $item->status }}</span></td>
                <td>{{ $item->catatan_pimpinan ?: '-' }}</td>
                <td class="actions">
                    <a href="{{ route('cuti.show', $item) }}">Detail</a>
                    @if($item->status === 'Diajukan')
                        <a href="{{ route('cuti.edit', $item) }}">Edit</a>
                        <form action="{{ route('cuti.destroy', $item) }}" method="POST" onsubmit="return confirm('Hapus pengajuan ini?')">@csrf @method('DELETE')<button type="submit" class="link-btn danger-text">Hapus</button></form>
                    @endif
                    @if(in_array(auth()->user()->role, ['admin','pimpinan']) && $item->status === 'Diajukan')
                        <form action="{{ route('cuti.approve', $item) }}" method="POST">@csrf<button type="submit" class="link-btn">Setujui</button></form>
                        <form action="{{ route('cuti.reject', $item) }}" method="POST">@csrf<input type="hidden" name="catatan_pimpinan" value="Ditolak melalui daftar."><button type="submit" class="link-btn danger-text">Tolak</button></form>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="6">Belum ada data cuti.</td></tr>
            @endforelse
        </tbody>
    </table>

    <div class="pagination-wrap">{{ $cuti->links() }}</div>
</div>
@endsection
