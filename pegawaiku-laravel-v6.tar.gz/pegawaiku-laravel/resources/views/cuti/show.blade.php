@extends('layouts.app')

@section('content')
<div class="card detail-card">
    <h3>Detail Cuti</h3>
    <div class="detail-grid">
        <div><strong>Pegawai</strong><p>{{ $cuti->pegawai->nama ?? '-' }}</p></div>
        <div><strong>Jenis</strong><p>{{ $cuti->jenis }}</p></div>
        <div><strong>Tanggal Mulai</strong><p>{{ $cuti->tanggal_mulai }}</p></div>
        <div><strong>Tanggal Selesai</strong><p>{{ $cuti->tanggal_selesai }}</p></div>
        <div><strong>Status</strong><p>{{ $cuti->status }}</p></div>
        <div><strong>Catatan Pimpinan</strong><p>{{ $cuti->catatan_pimpinan ?: '-' }}</p></div>
        <div style="grid-column:1/-1"><strong>Alasan</strong><p>{{ $cuti->alasan }}</p></div>
    </div>
    <div class="form-actions">
        <a href="{{ route('cuti.index') }}" class="btn secondary">Kembali</a>
    </div>
</div>
@endsection
