@extends('layouts.app')

@section('content')
<div class="grid stats-grid">
    <div class="card"><div class="kpi">{{ $stats['users'] }}</div><div class="muted">Total Users</div></div>
    <div class="card"><div class="kpi">{{ $stats['pegawai'] }}</div><div class="muted">Total Pegawai</div></div>
    <div class="card"><div class="kpi">{{ $stats['cuti'] }}</div><div class="muted">Total Cuti</div></div>
    <div class="card"><div class="kpi">{{ $stats['cuti_pending'] }}</div><div class="muted">Cuti Pending</div></div>
    <div class="card"><div class="kpi">{{ $stats['program'] }}</div><div class="muted">Total Program</div></div>
    <div class="card"><div class="kpi">{{ $stats['program_disetujui'] }}</div><div class="muted">Program Disetujui</div></div>
    <div class="card"><div class="kpi">{{ $stats['prestasi'] }}</div><div class="muted">Total Prestasi</div></div>
    <div class="card"><div class="kpi">Rp {{ number_format($stats['anggaran'], 0, ',', '.') }}</div><div class="muted">Total Anggaran</div></div>
</div>

<div class="grid two-col">
    <div class="card">
        <h3>Cuti Terbaru</h3>
        <table class="table">
            <thead><tr><th>Pegawai</th><th>Jenis</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($cutiTerbaru as $item)
                <tr>
                    <td>{{ $item->pegawai->nama ?? '-' }}</td>
                    <td>{{ $item->jenis }}</td>
                    <td>{{ $item->status }}</td>
                </tr>
                @empty
                <tr><td colspan="3">Belum ada data.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="card">
        <h3>Program Terbaru</h3>
        <table class="table">
            <thead><tr><th>Program</th><th>PJ</th><th>Status</th></tr></thead>
            <tbody>
                @forelse($programTerbaru as $item)
                <tr>
                    <td>{{ $item->nama }}</td>
                    <td>{{ $item->penanggungJawab->nama ?? '-' }}</td>
                    <td>{{ $item->status_approval }}</td>
                </tr>
                @empty
                <tr><td colspan="3">Belum ada data.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
