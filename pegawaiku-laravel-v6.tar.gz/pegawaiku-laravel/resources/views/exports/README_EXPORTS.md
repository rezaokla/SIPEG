Tahap export selanjutnya dapat memakai:
- maatwebsite/excel untuk export Excel
- barryvdh/laravel-dompdf untuk export PDF

Modul prioritas export:
- Laporan ringkasan
- Data pegawai
- Data cuti
- Data program dan anggaran
