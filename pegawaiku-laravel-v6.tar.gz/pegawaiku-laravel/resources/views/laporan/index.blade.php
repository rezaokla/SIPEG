@extends('layouts.app')

@section('content')
<div class="grid stats-grid">
    <div class="card"><div class="kpi">{{ $stats['pegawai'] }}</div><div class="muted">Total Pegawai</div></div>
    <div class="card"><div class="kpi">{{ $stats['cuti'] }}</div><div class="muted">Total Cuti</div></div>
    <div class="card"><div class="kpi">{{ $stats['cuti_disetujui'] }}</div><div class="muted">Cuti Disetujui</div></div>
    <div class="card"><div class="kpi">{{ $stats['program'] }}</div><div class="muted">Total Program</div></div>
    <div class="card"><div class="kpi">{{ $stats['program_disetujui'] }}</div><div class="muted">Program Disetujui</div></div>
    <div class="card"><div class="kpi">{{ $stats['prestasi'] }}</div><div class="muted">Total Prestasi</div></div>
    <div class="card"><div class="kpi">Rp {{ number_format($stats['anggaran'], 0, ',', '.') }}</div><div class="muted">Total Anggaran</div></div>
    <div class="card"><div class="kpi">Rp {{ number_format($stats['realisasi'], 0, ',', '.') }}</div><div class="muted">Total Realisasi</div></div>
</div>

<div class="grid two-col">
    <div class="card">
        <h3>Rekap Cuti</h3>
        <table class="table">
            <thead><tr><th>Status</th><th>Total</th></tr></thead>
            <tbody>
                @forelse($rekapCuti as $item)
                <tr><td>{{ $item->status }}</td><td>{{ $item->total }}</td></tr>
                @empty
                <tr><td colspan="2">Belum ada data.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="card">
        <h3>Rekap Program</h3>
        <table class="table">
            <thead><tr><th>Status</th><th>Total</th></tr></thead>
            <tbody>
                @forelse($rekapProgram as $item)
                <tr><td>{{ $item->status_approval }}</td><td>{{ $item->total }}</td></tr>
                @empty
                <tr><td colspan="2">Belum ada data.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <h3>Top 5 Pegawai Berprestasi</h3>
    <table class="table">
        <thead><tr><th>Pegawai</th><th>Total Prestasi</th></tr></thead>
        <tbody>
            @forelse($topPrestasi as $item)
            <tr><td>{{ $item->pegawai->nama ?? '-' }}</td><td>{{ $item->total }}</td></tr>
            @empty
            <tr><td colspan="2">Belum ada data.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
