@extends('layouts.app')

@section('content')
<div class="card form-card">
    <h3>Tambah Pegawai</h3>
    <form method="POST" action="{{ route('pegawai.store') }}">
        @csrf
        @include('pegawai.partials.form')
        <div class="form-actions">
            <a href="{{ route('pegawai.index') }}" class="btn secondary">Batal</a>
            <button type="submit" class="btn">Simpan</button>
        </div>
    </form>
</div>
@endsection
