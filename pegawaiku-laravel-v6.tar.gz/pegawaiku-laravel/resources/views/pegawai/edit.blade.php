@extends('layouts.app')

@section('content')
<div class="card form-card">
    <h3>Edit Pegawai</h3>
    <form method="POST" action="{{ route('pegawai.update', $pegawai) }}">
        @csrf @method('PUT')
        @include('pegawai.partials.form')
        <div class="form-actions">
            <a href="{{ route('pegawai.index') }}" class="btn secondary">Batal</a>
            <button type="submit" class="btn">Update</button>
        </div>
    </form>
</div>
@endsection
