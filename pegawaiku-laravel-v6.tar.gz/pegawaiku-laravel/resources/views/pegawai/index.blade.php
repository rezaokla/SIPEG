@extends('layouts.app')

@section('content')
<div class="card">
    <div class="toolbar">
        <form method="GET" class="filter-row multi">
            <input type="text" name="keyword" value="{{ request('keyword') }}" placeholder="Cari pegawai, NIP, jabatan, unit kerja">
            <select name="status_kepegawaian">
                <option value="">Semua Status</option>
                @foreach(['PNS','PPPK','Kontrak','Honorer'] as $status)
                    <option value="{{ $status }}" @selected(request('status_kepegawaian')===$status)>{{ $status }}</option>
                @endforeach
            </select>
            <select name="unit_kerja">
                <option value="">Semua Unit</option>
                @foreach($units as $unit)
                    <option value="{{ $unit }}" @selected(request('unit_kerja')===$unit)>{{ $unit }}</option>
                @endforeach
            </select>
            <button type="submit" class="btn">Filter</button>
        </form>
        <a href="{{ route('pegawai.create') }}" class="btn">+ Tambah Pegawai</a>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>NIP</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Unit Kerja</th>
                <th>Status</th>
                <th>Akun</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($pegawai as $item)
            <tr>
                <td>{{ $item->nip ?? '-' }}</td>
                <td>{{ $item->nama }}</td>
                <td>{{ $item->jabatan ?? '-' }}</td>
                <td>{{ $item->unit_kerja ?? '-' }}</td>
                <td><span class="badge">{{ $item->status_kepegawaian ?? '-' }}</span></td>
                <td>{{ $item->user?->email ?? 'Belum terhubung' }}</td>
                <td class="actions">
                    <a href="{{ route('pegawai.show', $item) }}">Detail</a>
                    <a href="{{ route('pegawai.edit', $item) }}">Edit</a>
                    <form action="{{ route('pegawai.destroy', $item) }}" method="POST" onsubmit="return confirm('Hapus data pegawai ini?')">
                        @csrf @method('DELETE')
                        <button type="submit" class="link-btn danger-text">Hapus</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="7">Belum ada data pegawai.</td></tr>
            @endforelse
        </tbody>
    </table>

    <div class="pagination-wrap">{{ $pegawai->links() }}</div>
</div>
@endsection
