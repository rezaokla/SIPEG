<div class="grid two-col">
    <div>
        <label>Akun User (opsional)</label>
        <select name="user_id">
            <option value="">Belum dihubungkan</option>
            @foreach($users as $user)
                <option value="{{ $user->id }}" @selected(old('user_id', $pegawai->user_id ?? '') == $user->id)>{{ $user->nama }} - {{ $user->email }}</option>
            @endforeach
        </select>
    </div>
    <div>
        <label>NIP</label>
        <input type="text" name="nip" value="{{ old('nip', $pegawai->nip ?? '') }}">
    </div>
    <div>
        <label>Nama</label>
        <input type="text" name="nama" value="{{ old('nama', $pegawai->nama ?? '') }}" required>
    </div>
    <div>
        <label>Jabatan</label>
        <input type="text" name="jabatan" value="{{ old('jabatan', $pegawai->jabatan ?? '') }}">
    </div>
    <div>
        <label>Unit Kerja</label>
        <input type="text" name="unit_kerja" value="{{ old('unit_kerja', $pegawai->unit_kerja ?? '') }}">
    </div>
    <div>
        <label>Status Kepegawaian</label>
        <select name="status_kepegawaian">
            <option value="">Pilih status</option>
            @foreach(['PNS','PPPK','Kontrak','Honorer'] as $status)
                <option value="{{ $status }}" @selected(old('status_kepegawaian', $pegawai->status_kepegawaian ?? '') === $status)>{{ $status }}</option>
            @endforeach
        </select>
    </div>
    <div>
        <label>Tanggal Mulai</label>
        <input type="date" name="tanggal_mulai" value="{{ old('tanggal_mulai', $pegawai->tanggal_mulai ?? '') }}">
    </div>
</div>
