@extends('layouts.app')

@section('content')
<div class="card detail-card">
    <h3>Detail Pegawai</h3>
    <div class="detail-grid three">
        <div><strong>NIP</strong><p>{{ $pegawai->nip ?? '-' }}</p></div>
        <div><strong>Nama</strong><p>{{ $pegawai->nama }}</p></div>
        <div><strong>Jabatan</strong><p>{{ $pegawai->jabatan ?? '-' }}</p></div>
        <div><strong>Unit Kerja</strong><p>{{ $pegawai->unit_kerja ?? '-' }}</p></div>
        <div><strong>Status</strong><p>{{ $pegawai->status_kepegawaian ?? '-' }}</p></div>
        <div><strong>Tanggal Mulai</strong><p>{{ $pegawai->tanggal_mulai }}</p></div>
        <div><strong>Email Akun</strong><p>{{ $pegawai->user?->email ?? 'Belum terhubung' }}</p></div>
        <div><strong>Total Cuti</strong><p>{{ $pegawai->cuti->count() }}</p></div>
        <div><strong>Total Prestasi</strong><p>{{ $pegawai->prestasi->count() }}</p></div>
    </div>
    <div class="form-actions">
        <a href="{{ route('pegawai.index') }}" class="btn secondary">Kembali</a>
        <a href="{{ route('pegawai.edit', $pegawai) }}" class="btn">Edit</a>
    </div>
</div>
@endsection
