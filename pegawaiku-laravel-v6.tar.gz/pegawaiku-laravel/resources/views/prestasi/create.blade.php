@extends('layouts.app')

@section('content')
<div class="card form-card">
    <h3>Tambah Prestasi</h3>
    <form method="POST" action="{{ route('prestasi.store') }}">
        @csrf
        @include('prestasi.partials.form')
        <div class="form-actions">
            <a href="{{ route('prestasi.index') }}" class="btn secondary">Batal</a>
            <button type="submit" class="btn">Simpan</button>
        </div>
    </form>
</div>
@endsection
