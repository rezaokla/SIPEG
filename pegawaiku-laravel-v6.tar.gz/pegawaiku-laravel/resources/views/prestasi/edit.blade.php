@extends('layouts.app')

@section('content')
<div class="card form-card">
    <h3>Edit Prestasi</h3>
    <form method="POST" action="{{ route('prestasi.update', $prestasi) }}">
        @csrf @method('PUT')
        @include('prestasi.partials.form')
        <div class="form-actions">
            <a href="{{ route('prestasi.index') }}" class="btn secondary">Batal</a>
            <button type="submit" class="btn">Update</button>
        </div>
    </form>
</div>
@endsection
