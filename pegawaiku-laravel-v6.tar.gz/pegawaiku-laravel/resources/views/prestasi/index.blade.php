@extends('layouts.app')

@section('content')
<div class="card">
    <div class="toolbar">
        <form method="GET" class="filter-row multi">
            <input type="text" name="keyword" value="{{ request('keyword') }}" placeholder="Cari pegawai, deskripsi, pemberi">
            <select name="kategori">
                <option value="">Semua Kategori</option>
                @foreach(['Penghargaan','Apresiasi','Tugas Luar Biasa','Inovasi'] as $kategori)
                    <option value="{{ $kategori }}" @selected(request('kategori')===$kategori)>{{ $kategori }}</option>
                @endforeach
            </select>
            <button type="submit" class="btn">Filter</button>
        </form>
        @if(in_array(auth()->user()->role, ['admin','pimpinan']))
            <a href="{{ route('prestasi.create') }}" class="btn">+ Tambah Prestasi</a>
        @endif
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>Pegawai</th>
                <th>Kategori</th>
                <th>Tanggal</th>
                <th>Pemberi</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($prestasi as $item)
            <tr>
                <td>{{ $item->pegawai->nama ?? '-' }}</td>
                <td>{{ $item->kategori }}</td>
                <td>{{ $item->tanggal }}</td>
                <td>{{ $item->pemberi }}</td>
                <td>{{ $item->deskripsi }}</td>
                <td class="actions">
                    <a href="{{ route('prestasi.show', $item) }}">Detail</a>
                    @if(in_array(auth()->user()->role, ['admin','pimpinan']))
                        <a href="{{ route('prestasi.edit', $item) }}">Edit</a>
                        <form action="{{ route('prestasi.destroy', $item) }}" method="POST" onsubmit="return confirm('Hapus prestasi ini?')">@csrf @method('DELETE')<button type="submit" class="link-btn danger-text">Hapus</button></form>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="6">Belum ada data prestasi.</td></tr>
            @endforelse
        </tbody>
    </table>

    <div class="pagination-wrap">{{ $prestasi->links() }}</div>
</div>
@endsection
