<label>Pegawai</label>
<select name="pegawai_id" required>
    @foreach($pegawaiList as $pegawai)
        <option value="{{ $pegawai->id }}" @selected(old('pegawai_id', $prestasi->pegawai_id ?? '') == $pegawai->id)>{{ $pegawai->nama }}</option>
    @endforeach
</select>
<label>Kategori</label>
<select name="kategori" required>
    @foreach(['Penghargaan','Apresiasi','Tugas Luar Biasa','Inovasi'] as $kategori)
        <option value="{{ $kategori }}" @selected(old('kategori', $prestasi->kategori ?? '') === $kategori)>{{ $kategori }}</option>
    @endforeach
</select>
<label>Tanggal</label>
<input type="date" name="tanggal" value="{{ old('tanggal', $prestasi->tanggal ?? '') }}" required>
<label>Pemberi</label>
<input type="text" name="pemberi" value="{{ old('pemberi', $prestasi->pemberi ?? '') }}" required>
<label>Deskripsi</label>
<textarea name="deskripsi" rows="4" required>{{ old('deskripsi', $prestasi->deskripsi ?? '') }}</textarea>
