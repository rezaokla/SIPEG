@extends('layouts.app')

@section('content')
<div class="card detail-card">
    <h3>Detail Prestasi</h3>
    <div class="detail-grid">
        <div><strong>Pegawai</strong><p>{{ $prestasi->pegawai->nama ?? '-' }}</p></div>
        <div><strong>Kategori</strong><p>{{ $prestasi->kategori }}</p></div>
        <div><strong>Tanggal</strong><p>{{ $prestasi->tanggal }}</p></div>
        <div><strong>Pemberi</strong><p>{{ $prestasi->pemberi }}</p></div>
        <div style="grid-column:1/-1"><strong>Deskripsi</strong><p>{{ $prestasi->deskripsi }}</p></div>
    </div>
    <div class="form-actions"><a href="{{ route('prestasi.index') }}" class="btn secondary">Kembali</a></div>
</div>
@endsection
