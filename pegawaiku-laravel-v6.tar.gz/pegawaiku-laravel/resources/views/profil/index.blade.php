@extends('layouts.app')

@section('content')
<div class="grid stats-grid">
    <div class="card"><div class="kpi">{{ $stats['cuti'] }}</div><div class="muted">Total Cuti</div></div>
    <div class="card"><div class="kpi">{{ $stats['prestasi'] }}</div><div class="muted">Total Prestasi</div></div>
</div>

<div class="grid two-col">
    <div class="card form-card">
        <h3>Profil Saya</h3>
        <form method="POST" action="{{ route('profil.update') }}">
            @csrf @method('PUT')
            <label>Nama</label>
            <input type="text" name="nama" value="{{ old('nama', $user->nama) }}" required>
            <label>Email</label>
            <input type="email" value="{{ $user->email }}" disabled>
            <label>Role</label>
            <input type="text" value="{{ $user->role }}" disabled>
            <label>NIP</label>
            <input type="text" name="nip" value="{{ old('nip', $pegawai->nip ?? '') }}">
            <label>Jabatan</label>
            <input type="text" name="jabatan" value="{{ old('jabatan', $pegawai->jabatan ?? '') }}">
            <label>Unit Kerja</label>
            <input type="text" name="unit_kerja" value="{{ old('unit_kerja', $pegawai->unit_kerja ?? '') }}">
            <div class="form-actions"><button type="submit" class="btn">Simpan Profil</button></div>
        </form>
    </div>

    <div class="card form-card">
        <h3>Ubah Password</h3>
        <form method="POST" action="{{ route('profil.password.update') }}">
            @csrf @method('PUT')
            <label>Password Lama</label>
            <input type="password" name="password_lama" required>
            <label>Password Baru</label>
            <input type="password" name="password" required>
            <label>Konfirmasi Password Baru</label>
            <input type="password" name="password_confirmation" required>
            <div class="form-actions"><button type="submit" class="btn">Ubah Password</button></div>
        </form>
    </div>
</div>
@endsection
