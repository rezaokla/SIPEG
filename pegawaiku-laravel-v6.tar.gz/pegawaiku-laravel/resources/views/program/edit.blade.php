@extends('layouts.app')

@section('content')
<div class="card form-card">
    <h3>Edit Program</h3>
    <form method="POST" action="{{ route('program.update', $program) }}">
        @csrf @method('PUT')
        @include('program.partials.form')
        <div class="form-actions">
            <a href="{{ route('program.index') }}" class="btn secondary">Batal</a>
            <button type="submit" class="btn">Update</button>
        </div>
    </form>
</div>
@endsection
