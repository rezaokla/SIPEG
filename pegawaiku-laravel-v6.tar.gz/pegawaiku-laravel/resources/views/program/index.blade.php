@extends('layouts.app')

@section('content')
<div class="card">
    <div class="toolbar">
        <form method="GET" class="filter-row multi">
            <input type="text" name="keyword" value="{{ request('keyword') }}" placeholder="Cari nama atau keterangan program">
            <input type="number" name="tahun" value="{{ request('tahun') }}" placeholder="Tahun">
            <select name="status_approval">
                <option value="">Semua Status</option>
                @foreach(['Diajukan','Disetujui','Ditolak','Revisi'] as $status)
                    <option value="{{ $status }}" @selected(request('status_approval')===$status)>{{ $status }}</option>
                @endforeach
            </select>
            <button type="submit" class="btn">Filter</button>
        </form>
        <a href="{{ route('program.create') }}" class="btn">+ Ajukan Program</a>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>Program</th>
                <th>Tahun</th>
                <th>PJ</th>
                <th>Anggaran</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($program as $item)
            <tr>
                <td>{{ $item->nama }}</td>
                <td>{{ $item->tahun }}</td>
                <td>{{ $item->penanggungJawab->nama ?? '-' }}</td>
                <td>Rp {{ number_format($item->anggaran, 0, ',', '.') }}</td>
                <td><span class="badge">{{ $item->status_approval }}</span></td>
                <td class="actions">
                    <a href="{{ route('program.show', $item) }}">Detail</a>
                    @if(in_array($item->status_approval, ['Diajukan','Revisi']))
                        <a href="{{ route('program.edit', $item) }}">Edit</a>
                        <form action="{{ route('program.destroy', $item) }}" method="POST" onsubmit="return confirm('Hapus program ini?')">@csrf @method('DELETE')<button type="submit" class="link-btn danger-text">Hapus</button></form>
                    @endif
                    @if(in_array(auth()->user()->role, ['admin','pimpinan']) && $item->status_approval === 'Diajukan')
                        <form action="{{ route('program.approve', $item) }}" method="POST">@csrf<button type="submit" class="link-btn">Setujui</button></form>
                        <form action="{{ route('program.reject', $item) }}" method="POST">@csrf<input type="hidden" name="catatan_pimpinan" value="Ditolak melalui daftar."><button type="submit" class="link-btn danger-text">Tolak</button></form>
                        <form action="{{ route('program.revisi', $item) }}" method="POST">@csrf<input type="hidden" name="catatan_pimpinan" value="Perlu revisi dari daftar."><button type="submit" class="link-btn">Revisi</button></form>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="6">Belum ada data program.</td></tr>
            @endforelse
        </tbody>
    </table>

    <div class="pagination-wrap">{{ $program->links() }}</div>
</div>
@endsection
