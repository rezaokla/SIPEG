@extends('layouts.app')

@section('content')
<div class="card detail-card">
    <h3>Detail Program</h3>
    <div class="detail-grid three">
        <div><strong>Nama</strong><p>{{ $program->nama }}</p></div>
        <div><strong>Tahun</strong><p>{{ $program->tahun }}</p></div>
        <div><strong>Status Approval</strong><p>{{ $program->status_approval }}</p></div>
        <div><strong>PJ</strong><p>{{ $program->penanggungJawab->nama ?? '-' }}</p></div>
        <div><strong>Pengaju</strong><p>{{ $program->pengaju->nama ?? '-' }}</p></div>
        <div><strong>Tahap</strong><p>{{ $program->tahap }}</p></div>
        <div><strong>Anggaran</strong><p>Rp {{ number_format($program->anggaran, 0, ',', '.') }}</p></div>
        <div><strong>Realisasi</strong><p>Rp {{ number_format($program->realisasi, 0, ',', '.') }}</p></div>
        <div><strong>Sisa</strong><p>Rp {{ number_format($program->sisa_anggaran, 0, ',', '.') }}</p></div>
        <div><strong>Tanggal Mulai</strong><p>{{ $program->tanggal_mulai }}</p></div>
        <div><strong>Tanggal Selesai</strong><p>{{ $program->tanggal_selesai }}</p></div>
        <div><strong>Catatan Pimpinan</strong><p>{{ $program->catatan_pimpinan ?: '-' }}</p></div>
        <div style="grid-column:1/-1"><strong>Keterangan</strong><p>{{ $program->keterangan }}</p></div>
    </div>

    @if(in_array(auth()->user()->role, ['admin','pimpinan']) && $program->status_approval === 'Disetujui')
    <div class="card" style="margin-top:16px">
        <h4>Update Realisasi</h4>
        <form method="POST" action="{{ route('program.realisasi', $program) }}">
            @csrf
            <label>Realisasi</label>
            <input type="number" name="realisasi" value="{{ $program->realisasi }}" min="0" required>
            <div class="form-actions">
                <button type="submit" class="btn">Simpan Realisasi</button>
            </div>
        </form>
    </div>
    @endif

    <div class="form-actions">
        <a href="{{ route('program.index') }}" class="btn secondary">Kembali</a>
    </div>
</div>
@endsection
